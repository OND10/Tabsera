using Data.Mapping;
using Data.Seeds;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Data.Context;

public class MyContext : DbContext
{
    public MyContext(DbContextOptions<MyContext> options) : base(options)
    {   
        Database.Migrate();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>(new UserMap().Configure);
        modelBuilder.Entity<WalletType>(new WalletTypeMap().Configure);
        modelBuilder.Entity<Wallet>(new WalletMap().Configure);
        modelBuilder.Entity<Category>(new CategoryMap().Configure);
        modelBuilder.Entity<Entrance>(new EntranceMap().Configure);
        modelBuilder.Entity<Log>(new LogMap().Configure);
        modelBuilder.Entity<Budget>(new BudgetMap().Configure);
        modelBuilder.Entity<AuditTrail>(new AuditTrailMap().Configure);

        UserSeeder.Users(modelBuilder);
        WalletTypeSeeder.WalletTypes(modelBuilder);
        WalletSeeder.Wallet(modelBuilder);
        CategorySeeder.Categories(modelBuilder);
    }
}
