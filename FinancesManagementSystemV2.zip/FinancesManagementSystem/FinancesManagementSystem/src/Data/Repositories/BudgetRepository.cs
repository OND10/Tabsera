using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Data.Context;
using Domain.Entities;
using Domain.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Data.Repositories;

public class BudgetRepository : BaseRepository<Budget>, IBudgetRepository
{
    public BudgetRepository(MyContext context) : base(context) { }

    public async Task<IEnumerable<Budget>> FindByUserAsync(Guid userId)
    {
        return await _dataset
            .Include(b => b.Category)
            .Include(b => b.Wallet)
            .Where(b => b.UserId == userId)
            .OrderBy(b => b.Name)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<IEnumerable<Budget>> FindAllWithDetailsAsync()
    {
        return await _dataset
            .Include(b => b.Category)
            .Include(b => b.Wallet)
            .OrderBy(b => b.Name)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<Budget> FindByIdWithDetailsAsync(Guid id)
    {
        return await _dataset
            .Include(b => b.Category)
            .Include(b => b.Wallet)
            .FirstOrDefaultAsync(b => b.Id == id);
    }
}
