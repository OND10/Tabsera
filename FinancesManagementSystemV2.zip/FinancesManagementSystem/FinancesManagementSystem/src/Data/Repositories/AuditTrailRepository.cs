using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Data.Context;
using Domain.Entities;
using Domain.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Data.Repositories;

public class AuditTrailRepository : BaseRepository<AuditTrail>, IAuditTrailRepository
{
    public AuditTrailRepository(MyContext context) : base(context) { }

    public async Task<IEnumerable<AuditTrail>> FindRecentAsync(int take = 200)
    {
        return await _dataset
            .OrderByDescending(a => a.CreatedAt)
            .Take(take)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<IEnumerable<AuditTrail>> FindByUserAsync(Guid userId, int take = 200)
    {
        return await _dataset
            .Where(a => a.UserId == userId)
            .OrderByDescending(a => a.CreatedAt)
            .Take(take)
            .AsNoTracking()
            .ToListAsync();
    }
}
