using Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Data.Mapping;

[ExcludeFromCodeCoverage]
public class AuditTrailMap : BaseMap<AuditTrail>
{
    public AuditTrailMap() : base("AuditTrails") { }

    public override void Configure(EntityTypeBuilder<AuditTrail> builder)
    {
        base.Configure(builder);

        builder.Property(a => a.Action)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(a => a.EntityName)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(a => a.Description)
            .HasMaxLength(500);

        builder.Property(a => a.UserEmail)
            .HasMaxLength(100);
    }
}
