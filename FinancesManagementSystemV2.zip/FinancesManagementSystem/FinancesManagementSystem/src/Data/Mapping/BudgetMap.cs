using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Data.Mapping;

[ExcludeFromCodeCoverage]
public class BudgetMap : BaseMap<Budget>
{
    public BudgetMap() : base("Budgets") { }

    public override void Configure(EntityTypeBuilder<Budget> builder)
    {
        base.Configure(builder);

        builder.Property(b => b.Name)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(b => b.Amount)
            .HasColumnType("decimal(18,2)")
            .IsRequired();

        builder.Property(b => b.AlertPercentage)
            .HasColumnType("decimal(5,2)")
            .HasDefaultValue(80m);

        builder.Property(b => b.Period)
            .IsRequired();

        builder.Property(b => b.IsActive)
            .HasDefaultValue(true);

        builder.HasOne(b => b.User)
            .WithMany()
            .OnDelete(DeleteBehavior.NoAction);

        builder.HasOne(b => b.Category)
            .WithMany()
            .OnDelete(DeleteBehavior.NoAction);

        builder.HasOne(b => b.Wallet)
            .WithMany()
            .OnDelete(DeleteBehavior.NoAction);
    }
}
