using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Domain.Dtos.Budget;
using Domain.Interfaces.Services;
using Domain.ViewModels.Budget;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Web.Controllers;

[ExcludeFromCodeCoverage]
[Authorize]
public class BudgetController : BaseController<BudgetController>
{
    private readonly IBudgetService _service;

    public BudgetController(IServiceProvider serviceProvider, ILogger<BudgetController> logger)
        : base(serviceProvider, logger) => _service = GetService<IBudgetService>();

    // ──────────────────────────────────────────────────────────────────
    //  Index – list the current user's budgets (admin sees all)
    // ──────────────────────────────────────────────────────────────────
    [HttpGet("Budget")]
    public async Task<IActionResult> Index()
    {
        try
        {
            GetClaims();
            ViewData["Title"] = "Budgets";

            if (IsAdmin)
            {
                var all = await _service.FindAllAsync();
                return View(all);
            }

            var userBudgets = await _service.FindByUserAsync(UserId);
            return View(userBudgets);
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Alerts – budget alert panel for the current user
    // ──────────────────────────────────────────────────────────────────
    [HttpGet("Budget/Alerts")]
    public async Task<IActionResult> Alerts()
    {
        try
        {
            GetClaims();
            ViewData["Title"] = "Budget Alerts";
            var alerts = await _service.FindAlertsAsync(UserId);
            return View(alerts);
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }

    // Returns alert data as JSON – used by the dashboard partial
    [HttpGet("Budget/AlertsData")]
    public async Task<IActionResult> AlertsData()
    {
        try
        {
            GetClaims();
            var alerts = await _service.FindAlertsAsync(UserId);
            return Ok(alerts);
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Create
    // ──────────────────────────────────────────────────────────────────
    [HttpGet("Budget/Create")]
    public async Task<IActionResult> Create()
    {
        try
        {
            GetClaims();
            var vm = await _service.SetupCreateViewModelAsync(UserId);
            ViewData["Title"] = "Create Budget";
            return View(vm);
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }

    [HttpPost("Budget/Create")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(BudgetCreateViewModel vm)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                GetClaims();
                vm = await _service.SetupCreateViewModelAsync(UserId);
                return View(vm);
            }

            GetClaims();
            var result = await _service.CreateAsync(vm.Budget, UserId);

            if (result == null)
                return BadRequest(ModelState);

            LoggingWarning($"Budget {result.Id} created by user {UserId}");
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Edit
    // ──────────────────────────────────────────────────────────────────
    [HttpGet("Budget/Edit/{id}")]
    public async Task<IActionResult> Edit(Guid id)
    {
        try
        {
            GetClaims();
            var vm = await _service.SetupUpdateViewModelAsync(id, UserId);

            if (vm?.Budget == null)
                return NotFound();

            // Non-admins can only edit their own budgets
            if (!IsAdmin && vm.Budget.Id != id)
                return Forbid();

            ViewData["Title"] = "Edit Budget";
            return View(vm);
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }

    [HttpPost("Budget/Edit/{id}")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(Guid id, BudgetUpdateViewModel vm)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                GetClaims();
                var refreshed = await _service.SetupUpdateViewModelAsync(id, UserId);
                refreshed.Budget = vm.Budget;
                return View(refreshed);
            }

            GetClaims();
            var result = await _service.UpdateAsync(vm.Budget, UserId);

            if (result == null)
                return BadRequest();

            LoggingWarning($"Budget {result.Id} updated by user {UserId}");
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Delete – any authenticated owner OR admin
    // ──────────────────────────────────────────────────────────────────
    [HttpGet("Budget/Delete/{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        try
        {
            GetClaims();
            // service UpdateAsync already checks ownership; DeleteAsync does too
            var result = await _service.DeleteAsync(id);

            if (!result)
                return BadRequest();

            LoggingWarning($"Budget {id} deleted by user {UserId}");
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            LoggingExceptions(ex);
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }
}
