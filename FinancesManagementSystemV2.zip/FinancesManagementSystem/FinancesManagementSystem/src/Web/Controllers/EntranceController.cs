using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Domain.Interfaces.Services;
using Domain.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OfficeOpenXml.Style;
using OfficeOpenXml;
using X.PagedList;

namespace Web.Controllers
{
    [ExcludeFromCodeCoverage]
    [Authorize]
    public class EntranceController : BaseController<EntranceController>
    {
        private readonly IEntranceService _service;

        public EntranceController(IServiceProvider serviceProvider, ILogger<EntranceController> logger) : 
            base(serviceProvider, logger) => _service = GetService<IEntranceService>();

        [HttpGet("Entrance")]
        public ViewResult Index(
            string currentSort,
            string searchString, 
            int? page,
            int pageSize = 10
        )
        {
            currentSort = string.IsNullOrEmpty(currentSort) ? "" : currentSort;

            ViewBag.ValueSort = currentSort == "value" ? "value_desc" : "value";
            ViewBag.DescriptionSort = currentSort == "description" ? "description_desc" : "description";
            ViewBag.CategorySort = currentSort == "category" ? "category_desc" : "category";
            ViewBag.TypeSort = currentSort == "type" ? "type_desc" : "type";
            ViewBag.CreatedAtSort = currentSort == "createdAt" ? "" : "createdAt";

            if (searchString != null)
                page = 1;

            ViewBag.SearchString = searchString;
            ViewBag.PageSize = pageSize;
            
            GetClaims();

            var entrances = _service.FindAllWithCategory(
                currentSort,
                searchString,
                UserId
            ).GetAwaiter().GetResult();

            var pageNumber = page ?? 1;

            return View(entrances?.ToPagedList(pageNumber, pageSize));
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            try
            {
                GetClaims();
                
                var result = await _service.SetupEntranceCreateViewModel(UserId);
                
                return View(result);
            }
            catch (Exception exception)
            {
                LoggingExceptions(exception);
                return StatusCode(StatusCodes.Status500InternalServerError, exception.Message);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EntranceCreateViewModel entraceCreateViewModel)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var result = await _service.CreateAsync(entraceCreateViewModel.Entrance);
                
                if (result == null)
                    return BadRequest(ModelState);

                LoggingWarning($"Entrance {result.Id} created with success");
                
                return RedirectToAction("Index", "Entrance");
            }
            catch (Exception exception)
            {
                LoggingExceptions(exception);
                return StatusCode(StatusCodes.Status500InternalServerError, exception.Message);
            }
        }

        [HttpGet("Entrances/Edit/{Id}")]
        public async Task<IActionResult> Edit(Guid id)
        {
            try
            {
                GetClaims();
                
                var result = await _service.SetupEntranceUpdateViewModel(UserId, id);
                
                return View(result);
            }
            catch (Exception exception)
            {
                LoggingExceptions(exception);
                return StatusCode(StatusCodes.Status500InternalServerError, exception.Message);
            }
        }

        [HttpPost("Entrances/Edit/{Id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, EntranceUpdateViewModel entraceUpdateView)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var result = await _service.UpdateAsync(entraceUpdateView.Entrance);
                if (result == null)
                    return BadRequest(ModelState);

                LoggingWarning($"Entrance {result.Id} updated with success");
                
                return RedirectToAction("Index", "Entrance");
            }
            catch (Exception exception)
            {
                LoggingExceptions(exception);
                return StatusCode(StatusCodes.Status500InternalServerError, exception.Message);
            }
        }

        [HttpGet("Entrance/Delete/{Id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var result = await _service.DeleteAsync(id);
                if (result.Equals(null))
                    return BadRequest(ModelState);

                LoggingWarning($"Entrance {id} deleted with success");
                
                return RedirectToAction("Index", "Entrance");
            }
            catch (Exception exception)
            {
                LoggingExceptions(exception);
                return StatusCode(StatusCodes.Status500InternalServerError, exception.Message);
            }
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ExportToExcel(string searchString)
        {
            try
            {
                GetClaims();

                // Get all records filtered (if search applied)
                var entrances = await _service.FindAllWithCategory("", searchString, UserId);

                if (entrances == null || !entrances.Any())
                    return NotFound("No data available for export.");

                // FIX: Use the EPPlus 8 compliant registration method here
                OfficeOpenXml.ExcelPackage.License.SetNonCommercialPersonal("Osama Dammag");

                using var package = new ExcelPackage();
                var worksheet = package.Workbook.Worksheets.Add("Entrances");

                // Define headers (same as table columns)
                var headers = new[]
                {
            "تاريخ الانشاء", "الوصف", "المبلغ", "لغرض", "نوع العملية"
        };

                for (int i = 0; i < headers.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = headers[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    worksheet.Cells[1, i + 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    worksheet.Cells[1, i + 1].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
                    worksheet.Cells[1, i + 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                }

                // Fill data
                int row = 2;
                foreach (var e in entrances)
                {
                    worksheet.Cells[row, 1].Value = e.CreatedAt.ToString("yyyy-MM-dd HH:mm");
                    worksheet.Cells[row, 2].Value = e.Description;
                    worksheet.Cells[row, 3].Value = e.Value;
                    worksheet.Cells[row, 4].Value = e.Category?.Name;
                    worksheet.Cells[row, 5].Value = e.Type switch
                    {
                        1 => "ربح",
                        2 => "خسارة",
                        _ => "غير معروف"
                    };
                    row++;
                }

                worksheet.Cells.AutoFitColumns();

                var stream = new MemoryStream(package.GetAsByteArray());
                var fileName = $"Entrances_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

                return File(stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
            catch (Exception ex)
            {
                LoggingExceptions(ex);
                return StatusCode(500, "Error generating Excel file: " + ex.Message);
            }
        }
    }
}
