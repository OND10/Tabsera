using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Domain.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Web.Controllers;

[ExcludeFromCodeCoverage]
[Authorize]
public class ReportsController : BaseController<ReportsController>
{
    private readonly IEntranceService _entranceService;

    public ReportsController(IServiceProvider serviceProvider, ILogger<ReportsController> logger)
        : base(serviceProvider, logger) => _entranceService = GetService<IEntranceService>();

    [HttpGet("Reports")]
    public IActionResult Index()
    {
        ViewData["Title"] = "Reports";
        return View();
    }

    [HttpGet("Reports/DailyClose")]
    public async Task<IActionResult> DailyClose(DateTime? date)
    {
        try
        {
            GetClaims();

            var reportDate = date ?? DateTime.Today;
            var result = await _entranceService.FindDailyCloseReportAsync(UserId, reportDate);

            ViewData["Title"] = "Daily Close";

            return View(result);
        }
        catch (Exception exception)
        {
            LoggingExceptions(exception);
            return StatusCode(500, exception.Message);
        }
    }

    [HttpGet("Reports/Summary")]
    public async Task<IActionResult> Summary(DateTime? startDate, DateTime? endDate)
    {
        try
        {
            GetClaims();

            var reportEndDate = endDate ?? DateTime.Today;
            var reportStartDate = startDate ?? new DateTime(reportEndDate.Year, reportEndDate.Month, 1);
            var result = await _entranceService.FindReportSummaryAsync(UserId, reportStartDate, reportEndDate);

            ViewData["Title"] = "Report Summary";

            return View(result);
        }
        catch (Exception exception)
        {
            LoggingExceptions(exception);
            return StatusCode(500, exception.Message);
        }
    }
}
