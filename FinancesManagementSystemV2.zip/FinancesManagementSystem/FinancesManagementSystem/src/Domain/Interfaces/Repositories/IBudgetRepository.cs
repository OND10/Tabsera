using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain.Entities;

namespace Domain.Interfaces.Repositories;

public interface IBudgetRepository : IBaseRepository<Budget>
{
    Task<IEnumerable<Budget>> FindByUserAsync(Guid userId);
    Task<IEnumerable<Budget>> FindAllWithDetailsAsync();
    Task<Budget> FindByIdWithDetailsAsync(Guid id);
}
