using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain.Entities;

namespace Domain.Interfaces.Repositories;

public interface IAuditTrailRepository : IBaseRepository<AuditTrail>
{
    Task<IEnumerable<AuditTrail>> FindRecentAsync(int take = 200);
    Task<IEnumerable<AuditTrail>> FindByUserAsync(Guid userId, int take = 200);
}
