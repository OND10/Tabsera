using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain.Dtos.AuditTrail;

namespace Domain.Interfaces.Services;

public interface IAuditTrailService : IBaseService
{
    Task<IEnumerable<AuditTrailResultDto>> FindRecentAsync(int take = 200);
    Task<IEnumerable<AuditTrailResultDto>> FindByUserAsync(Guid userId, int take = 200);
    Task LogAsync(string action, string entityName, Guid? entityId, string description, Guid? userId, string userEmail);
}
