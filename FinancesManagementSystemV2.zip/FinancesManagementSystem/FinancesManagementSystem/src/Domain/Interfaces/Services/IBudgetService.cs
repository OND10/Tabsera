using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain.Dtos.Budget;
using Domain.ViewModels.Budget;

namespace Domain.Interfaces.Services;

public interface IBudgetService : IBaseService
{
    Task<IEnumerable<BudgetResultDto>> FindByUserAsync(Guid userId);
    Task<IEnumerable<BudgetResultDto>> FindAllAsync();
    Task<BudgetUpdateDto> FindByIdUpdateAsync(Guid id);
    Task<IEnumerable<BudgetAlertViewModel>> FindAlertsAsync(Guid userId);
    Task<BudgetCreateViewModel> SetupCreateViewModelAsync(Guid userId);
    Task<BudgetUpdateViewModel> SetupUpdateViewModelAsync(Guid id, Guid userId);
    Task<BudgetResultDto> CreateAsync(BudgetCreateDto budgetCreateDto, Guid userId);
    Task<BudgetResultDto> UpdateAsync(BudgetUpdateDto budgetUpdateDto, Guid userId);
    Task<bool> DeleteAsync(Guid id);
}
