using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain.Dtos.Entrance;
using Domain.Dtos.EntranceTypeDto;
using Domain.ViewModels;
using Domain.ViewModels.Reports;

namespace Domain.Interfaces.Services;

public interface IEntranceService : IBaseService
{
    Task<EntranceResultDto> FindByIdAsync(Guid id);
    Task<EntranceUpdateDto> FindByIdUpdateAsync(Guid id);

    Task<IEnumerable<EntranceResultDto>> FindAllWithCategory(
        string currentSort,
        string searchString,
        Guid userId
    );

    Task<IEnumerable<EntranceResultDto>> FindAllWithCategoryAdmin(string currentSort, string searchString);
    Task<IEnumerable<EntranceResultDto>> FindAsyncLastFiveEntrancesWithCategories(Guid userId);
    List<EntranceTypeResultDto> FindEntranceTypes();
    Task<DailyCloseViewModel> FindDailyCloseReportAsync(Guid userId, DateTime reportDate, Guid? walletId = null, Guid? categoryId = null);
    Task<ReportSummaryViewModel> FindReportSummaryAsync(Guid userId, DateTime startDate, DateTime endDate, Guid? walletId = null, Guid? categoryId = null);

    Task<EntranceCreateViewModel> SetupEntranceCreateViewModel(Guid userId);
    Task<EntranceUpdateViewModel> SetupEntranceUpdateViewModel(Guid userId, Guid id);

    Task<EntranceResultDto> CreateAsync(EntranceCreateDto entraceCreateDto);
    Task<EntranceResultDto> UpdateAsync(EntranceUpdateDto entraceUpdateDto);
    Task<bool> DeleteAsync(Guid id);
}
