using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Dtos.AuditTrail;
using Domain.Entities;
using Domain.Interfaces.Repositories;
using Domain.Interfaces.Services;
using Domain.Mappers;

namespace Domain.Services;

public class AuditTrailService : IAuditTrailService
{
    private readonly IAuditTrailRepository _repository;

    public AuditTrailService(IAuditTrailRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<AuditTrailResultDto>> FindRecentAsync(int take = 200)
    {
        var audits = await _repository.FindRecentAsync(take);
        return audits.Select(a => a.MapperResultDto());
    }

    public async Task<IEnumerable<AuditTrailResultDto>> FindByUserAsync(Guid userId, int take = 200)
    {
        var audits = await _repository.FindByUserAsync(userId, take);
        return audits.Select(a => a.MapperResultDto());
    }

    public async Task LogAsync(string action, string entityName, Guid? entityId, string description, Guid? userId, string userEmail)
    {
        var audit = new AuditTrail
        {
            Action = action,
            EntityName = entityName,
            EntityId = entityId,
            Description = description,
            UserId = userId,
            UserEmail = userEmail
        };

        _ = await _repository.CreateAsync(audit);
    }
}
