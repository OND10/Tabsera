using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Dtos.Budget;
using Domain.Enums;
using Domain.Interfaces.Repositories;
using Domain.Interfaces.Services;
using Domain.Mappers;
using Domain.ViewModels.Budget;

namespace Domain.Services;

public class BudgetService : IBudgetService
{
    private readonly IBudgetRepository _repository;
    private readonly IEntranceService _entranceService;
    private readonly ICategoryService _categoryService;
    private readonly IWalletService _walletService;

    public BudgetService(
        IBudgetRepository repository,
        IEntranceService entranceService,
        ICategoryService categoryService,
        IWalletService walletService)
    {
        _repository = repository;
        _entranceService = entranceService;
        _categoryService = categoryService;
        _walletService = walletService;
    }


    public async Task<IEnumerable<BudgetResultDto>> FindByUserAsync(Guid userId)
    {
        var budgets = await _repository.FindByUserAsync(userId);
        return budgets.Select(b => b.MapperResultDto());
    }

    public async Task<IEnumerable<BudgetResultDto>> FindAllAsync()
    {
        var budgets = await _repository.FindAllWithDetailsAsync();
        return budgets.Select(b => b.MapperResultDto());
    }

    public async Task<BudgetUpdateDto> FindByIdUpdateAsync(Guid id)
    {
        var budget = await _repository.FindByIdWithDetailsAsync(id);
        return budget.MapperUpdateDto();
    }

    public async Task<IEnumerable<BudgetAlertViewModel>> FindAlertsAsync(Guid userId)
    {
        var budgets = (await _repository.FindByUserAsync(userId)).Where(b => b.IsActive).ToList();
        var alerts = new List<BudgetAlertViewModel>();

        foreach (var budget in budgets)
        {
            var (startDate, endDate) = GetCurrentPeriodRange(budget.Period, DateTime.Today);
            var report = await _entranceService.FindReportSummaryAsync(
                userId,
                startDate,
                endDate,
                budget.WalletId,
                budget.CategoryId
            );

            alerts.Add(new BudgetAlertViewModel
            {
                Budget = budget.MapperResultDto(),
                Spent = report.TotalExpense
            });
        }

        return alerts.OrderByDescending(a => a.IsExceeded).ThenByDescending(a => a.IsAlert).ThenByDescending(a => a.UsedPercentage);
    }

    public async Task<BudgetResultDto> CreateAsync(BudgetCreateDto budgetCreateDto, Guid userId)
    {
        var entity = budgetCreateDto.Mapper(userId);
        _ = await _repository.CreateAsync(entity);
        return entity.MapperResultDto();
    }

    public async Task<BudgetResultDto> UpdateAsync(BudgetUpdateDto budgetUpdateDto, Guid userId)
    {
        var existing = await _repository.FindByIdAsync(budgetUpdateDto.Id, true);
        if (existing == null || existing.UserId != userId)
            return null;

        var entity = budgetUpdateDto.Mapper(userId);
        _ = await _repository.UpdateAsync(entity);
        return entity.MapperResultDto();
    }

    public async Task<BudgetCreateViewModel> SetupCreateViewModelAsync(Guid userId)
    {
        return new BudgetCreateViewModel
        {
            Categories = await _categoryService.FindAsyncAllCommonAndUserCategories(userId),
            Wallets = await _walletService.FindAsyncWalletsUser(userId)
        };
    }

    public async Task<BudgetUpdateViewModel> SetupUpdateViewModelAsync(Guid id, Guid userId)
    {
        return new BudgetUpdateViewModel
        {
            Budget = await FindByIdUpdateAsync(id),
            Categories = await _categoryService.FindAsyncAllCommonAndUserCategories(userId),
            Wallets = await _walletService.FindAsyncWalletsUser(userId)
        };
    }

    public async Task<bool> DeleteAsync(Guid id) => await _repository.DeleteAsync(id);

    private static (DateTime StartDate, DateTime EndDate) GetCurrentPeriodRange(ReportPeriod period, DateTime today)
    {
        return period switch
        {
            ReportPeriod.Daily => (today.Date, today.Date),
            ReportPeriod.Weekly => (today.Date.AddDays(-(int)today.DayOfWeek), today.Date),
            ReportPeriod.Monthly => (new DateTime(today.Year, today.Month, 1), today.Date),
            ReportPeriod.Yearly => (new DateTime(today.Year, 1, 1), today.Date),
            _ => (new DateTime(today.Year, today.Month, 1), today.Date)
        };
    }
}
