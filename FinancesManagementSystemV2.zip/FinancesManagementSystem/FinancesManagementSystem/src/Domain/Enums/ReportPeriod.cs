namespace Domain.Enums;

public enum ReportPeriod
{
    Daily = 1,
    Weekly = 2,
    Monthly = 3,
    Yearly = 4,
    Custom = 5
}
