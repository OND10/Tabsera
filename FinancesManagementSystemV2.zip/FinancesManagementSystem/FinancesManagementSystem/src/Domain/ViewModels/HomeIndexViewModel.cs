using System.Collections.Generic;
using Domain.Dtos.Entrance;
using Domain.ViewModels.Budget;

namespace Domain.ViewModels;

public class HomeIndexViewModel
{
    public IEnumerable<EntranceResultDto> RecentEntrances { get; set; }
    public IEnumerable<BudgetAlertViewModel> BudgetAlerts { get; set; }
}
