using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Domain.Dtos.Category;
using Domain.Dtos.Entrance;
using Domain.Dtos.User;
using Domain.Dtos.Wallet;
using Domain.Enums;

namespace Domain.ViewModels.Reports;

public class ReportSummaryViewModel
{
    public ReportSummaryViewModel()
    {
        Entries = new List<EntranceResultDto>();
        WalletBreakdown = new List<ReportBreakdownViewModel>();
        CategoryBreakdown = new List<ReportBreakdownViewModel>();
        Users = new List<UserResultDto>();
        Wallets = new List<WalletResultDto>();
        Categories = new List<CategoryResultDto>();
    }

    [Display(Name = "Start Date")]
    [DataType(DataType.Date)]
    public DateTime StartDate { get; set; }

    [Display(Name = "End Date")]
    [DataType(DataType.Date)]
    public DateTime EndDate { get; set; }

    public ReportPeriod Period { get; set; }
    public Guid? SelectedUserId { get; set; }
    public Guid? SelectedWalletId { get; set; }
    public Guid? SelectedCategoryId { get; set; }
    public bool IsAdminReport { get; set; }

    [Display(Name = "Total Income")]
    [DataType(DataType.Currency)]
    public decimal TotalIncome { get; set; }

    [Display(Name = "Total Expense")]
    [DataType(DataType.Currency)]
    public decimal TotalExpense { get; set; }

    [Display(Name = "Total Transfer")]
    [DataType(DataType.Currency)]
    public decimal TotalTransfer { get; set; }

    [Display(Name = "Net Movement")]
    [DataType(DataType.Currency)]
    public decimal NetMovement => TotalIncome - TotalExpense;

    [Display(Name = "Entries Count")]
    public int EntriesCount => Entries?.Count() ?? 0;

    public IEnumerable<EntranceResultDto> Entries { get; set; }
    public IEnumerable<ReportBreakdownViewModel> WalletBreakdown { get; set; }
    public IEnumerable<ReportBreakdownViewModel> CategoryBreakdown { get; set; }
    public IEnumerable<UserResultDto> Users { get; set; }
    public IEnumerable<WalletResultDto> Wallets { get; set; }
    public IEnumerable<CategoryResultDto> Categories { get; set; }
}
