using System.ComponentModel.DataAnnotations;

namespace Domain.ViewModels.Reports;

public class ReportBreakdownViewModel
{
    [Display(Name = "Name")]
    public string Name { get; set; }

    [Display(Name = "Income")]
    [DataType(DataType.Currency)]
    public decimal Income { get; set; }

    [Display(Name = "Expense")]
    [DataType(DataType.Currency)]
    public decimal Expense { get; set; }

    [Display(Name = "Transfer")]
    [DataType(DataType.Currency)]
    public decimal Transfer { get; set; }

    [Display(Name = "Net")]
    [DataType(DataType.Currency)]
    public decimal Net => Income - Expense;

    [Display(Name = "Entries")]
    public int EntriesCount { get; set; }
}
