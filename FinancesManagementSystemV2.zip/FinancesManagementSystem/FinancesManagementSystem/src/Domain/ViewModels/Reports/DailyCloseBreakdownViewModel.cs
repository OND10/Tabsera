namespace Domain.ViewModels.Reports;

public class DailyCloseBreakdownViewModel : ReportBreakdownViewModel
{
}
