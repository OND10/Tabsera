using System;
using System.ComponentModel.DataAnnotations;

namespace Domain.ViewModels.Reports;

public class DailyCloseViewModel : ReportSummaryViewModel
{
    [Display(Name = "Report Date")]
    [DataType(DataType.Date)]
    [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
    public DateTime ReportDate { get; set; }
}
