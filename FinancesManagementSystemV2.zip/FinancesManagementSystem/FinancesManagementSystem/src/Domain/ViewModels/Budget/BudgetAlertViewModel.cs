using Domain.Dtos.Budget;

namespace Domain.ViewModels.Budget;

public class BudgetAlertViewModel
{
    public BudgetResultDto Budget { get; set; }
    public decimal Spent { get; set; }
    public decimal Remaining => Budget == null ? 0m : Budget.Amount - Spent;
    public decimal UsedPercentage => Budget == null || Budget.Amount <= 0m ? 0m : decimal.Round((Spent / Budget.Amount) * 100m, 2);
    public bool IsAlert => Budget != null && UsedPercentage >= Budget.AlertPercentage;
    public bool IsExceeded => Budget != null && Spent > Budget.Amount;
}
