using System.Collections.Generic;
using Domain.Dtos.Budget;
using Domain.Dtos.Category;
using Domain.Dtos.Wallet;

namespace Domain.ViewModels.Budget;

public class BudgetUpdateViewModel
{
    public BudgetUpdateViewModel()
    {
        Budget = new BudgetUpdateDto();
        Categories = new List<CategoryResultDto>();
        Wallets = new List<WalletResultDto>();
    }

    public BudgetUpdateDto Budget { get; set; }
    public IEnumerable<CategoryResultDto> Categories { get; set; }
    public IEnumerable<WalletResultDto> Wallets { get; set; }
}
