using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Domain.Dtos.Wallet
{
    public class WalletTotalValuesDto
    {
        public WalletTotalValuesDto()
        {
            WalletsValues = new List<WalletValuesDto>();
        }

        [DataType(DataType.Currency)]
        public decimal TotalIncomes { get; set; }

        [DataType(DataType.Currency)]
        public decimal TotalExpanses { get; set; }

        public IEnumerable<WalletValuesDto> WalletsValues { get; set; }
    }
}
