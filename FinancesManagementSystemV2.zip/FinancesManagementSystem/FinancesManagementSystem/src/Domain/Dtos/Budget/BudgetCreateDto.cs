using System;
using System.ComponentModel.DataAnnotations;
using Domain.Enums;

namespace Domain.Dtos.Budget;

public class BudgetCreateDto
{
    [Required]
    [StringLength(100)]
    public string Name { get; set; }

    [Required]
    [DataType(DataType.Currency)]
    public decimal Amount { get; set; }

    [Range(1, 100)]
    public decimal AlertPercentage { get; set; } = 80m;

    [Required]
    public ReportPeriod Period { get; set; }

    [Required]
    public Guid CategoryId { get; set; }

    public Guid? WalletId { get; set; }
}
