using System;
using System.ComponentModel.DataAnnotations;
using Domain.Dtos.Category;
using Domain.Dtos.Entity;
using Domain.Dtos.Wallet;
using Domain.Enums;

namespace Domain.Dtos.Budget;

public class BudgetResultDto : EntityResultDto
{
    public string Name { get; set; }

    [DataType(DataType.Currency)]
    public decimal Amount { get; set; }

    public decimal AlertPercentage { get; set; }
    public ReportPeriod Period { get; set; }
    public bool IsActive { get; set; }
    public Guid UserId { get; set; }
    public Guid CategoryId { get; set; }
    public Guid? WalletId { get; set; }
    public CategoryResultDto Category { get; set; }
    public WalletResultDto Wallet { get; set; }
}
