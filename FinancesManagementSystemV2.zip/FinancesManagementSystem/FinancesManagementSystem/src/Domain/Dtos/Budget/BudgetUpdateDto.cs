using System;
using Domain.Dtos.Entity;
using Domain.Enums;

namespace Domain.Dtos.Budget;

public class BudgetUpdateDto : EntityUpdateDto
{
    public string Name { get; set; }
    public decimal Amount { get; set; }
    public decimal AlertPercentage { get; set; }
    public ReportPeriod Period { get; set; }
    public bool IsActive { get; set; }
    public Guid CategoryId { get; set; }
    public Guid? WalletId { get; set; }
}
