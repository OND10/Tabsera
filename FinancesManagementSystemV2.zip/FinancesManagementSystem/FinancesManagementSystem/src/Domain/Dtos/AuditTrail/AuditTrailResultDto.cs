using System;
using Domain.Dtos.Entity;

namespace Domain.Dtos.AuditTrail;

public class AuditTrailResultDto : EntityResultDto
{
    public string Action { get; set; }
    public string EntityName { get; set; }
    public Guid? EntityId { get; set; }
    public string Description { get; set; }
    public Guid? UserId { get; set; }
    public string UserEmail { get; set; }
}
