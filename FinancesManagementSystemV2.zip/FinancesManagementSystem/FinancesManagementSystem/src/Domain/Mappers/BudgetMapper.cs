using Domain.Dtos.Budget;
using Domain.Entities;

namespace Domain.Mappers;

public static class BudgetMapper
{
    public static Budget Mapper(this BudgetCreateDto dto, System.Guid userId)
    {
        return new Budget
        {
            Name = dto.Name,
            Amount = dto.Amount,
            AlertPercentage = dto.AlertPercentage,
            Period = dto.Period,
            UserId = userId,
            CategoryId = dto.CategoryId,
            WalletId = dto.WalletId,
            IsActive = true
        };
    }

    public static Budget Mapper(this BudgetUpdateDto dto, System.Guid userId)
    {
        return new Budget
        {
            Id = dto.Id,
            Name = dto.Name,
            Amount = dto.Amount,
            AlertPercentage = dto.AlertPercentage,
            Period = dto.Period,
            UserId = userId,
            CategoryId = dto.CategoryId,
            WalletId = dto.WalletId,
            IsActive = dto.IsActive
        };
    }

    public static BudgetResultDto MapperResultDto(this Budget entity)
    {
        if (entity == null)
            return null;

        return new BudgetResultDto
        {
            Id = entity.Id,
            Name = entity.Name,
            Amount = entity.Amount,
            AlertPercentage = entity.AlertPercentage,
            Period = entity.Period,
            IsActive = entity.IsActive,
            UserId = entity.UserId,
            CategoryId = entity.CategoryId,
            WalletId = entity.WalletId,
            CreatedAt = entity.CreatedAt,
            UpdatedAt = entity.UpdatedAt,
            Category = entity.Category?.MapperToResultDto(),
            Wallet = entity.Wallet?.MapperResultDto()
        };
    }

    public static BudgetUpdateDto MapperUpdateDto(this Budget entity)
    {
        if (entity == null)
            return null;

        return new BudgetUpdateDto
        {
            Id = entity.Id,
            Name = entity.Name,
            Amount = entity.Amount,
            AlertPercentage = entity.AlertPercentage,
            Period = entity.Period,
            IsActive = entity.IsActive,
            CategoryId = entity.CategoryId,
            WalletId = entity.WalletId
        };
    }
}
