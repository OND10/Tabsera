using System;
using Domain.Dtos.AuditTrail;
using Domain.Entities;

namespace Domain.Mappers;

public static class AuditTrailMapper
{
    public static AuditTrailResultDto MapperResultDto(this AuditTrail entity)
    {
        if (entity == null)
            return null;

        return new AuditTrailResultDto
        {
            Id = entity.Id,
            Action = entity.Action,
            EntityName = entity.EntityName,
            EntityId = entity.EntityId,
            Description = entity.Description,
            UserId = entity.UserId,
            UserEmail = entity.UserEmail,
            CreatedAt = entity.CreatedAt,
            UpdatedAt = entity.UpdatedAt
        };
    }
}
