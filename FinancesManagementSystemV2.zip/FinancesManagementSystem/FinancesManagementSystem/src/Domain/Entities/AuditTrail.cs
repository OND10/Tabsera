using System;

namespace Domain.Entities;

public class AuditTrail : Entity
{
    public string Action { get; set; }
    public string EntityName { get; set; }
    public Guid? EntityId { get; set; }
    public string Description { get; set; }
    public Guid? UserId { get; set; }
    public string UserEmail { get; set; }
}
