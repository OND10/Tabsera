using Domain.Enums;
using System;

namespace Domain.Entities;

public class Budget : Entity
{
    public string Name { get; set; }
    public decimal Amount { get; set; }
    public decimal AlertPercentage { get; set; }
    public ReportPeriod Period { get; set; }
    public bool IsActive { get; set; }

    public Guid UserId { get; set; }
    public User User { get; set; }

    public Guid CategoryId { get; set; }
    public Category Category { get; set; }

    public Guid? WalletId { get; set; }
    public Wallet Wallet { get; set; }
}
