using System.Diagnostics.CodeAnalysis;
using Data.Context;
using Data.Repositories;
using Domain.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace CrossCutting.DependencyInjection
{
    [ExcludeFromCodeCoverage]
    public static class ConfigureRepository
    {
        public static void ConfigureDependenciesRepository(IServiceCollection service)
        {
            service.AddScoped<IUserRepository, UserRepository>();
            service.AddScoped<IWalletTypeRepository, WalletTypeRepository>();
            service.AddScoped<IWalletRepository, WalletRepository>();
            service.AddScoped<ICategoryRepository, CategoryRepository>();
            service.AddScoped<IEntranceRepository, EntranceRepository>();
            service.AddScoped<IBudgetRepository, BudgetRepository>();
            service.AddScoped<IAuditTrailRepository, AuditTrailRepository>();

            string connectionstring = "Server=(localdb)\\MSSQLLocalDB;Database=FinancesSystemDb;Trusted_Connection=True;TrustServerCertificate=true";
            service.AddDbContext<MyContext>(
                options => options.UseSqlServer(connectionString: connectionstring)
            );
        }
    }
}
